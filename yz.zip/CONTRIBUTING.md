<!--
SPDX-FileCopyrightText: 2018 yuzu Emulator Project
SPDX-FileCopyrightText: 2024 suyu Emulator Project
SPDX-License-Identifier: GPL-2.0-or-later
-->

Please check out the

 * [Contributors's guide](https://git.suyu.dev/suyu/suyu/wiki/Contributing).
 * [Merge request guidelines](https://git.suyu.dev/suyu/suyu/wiki/Typical-Git-Workflow#once-your-pull-request-is-ready-to-be-merged)
